$("#btn-show").click(function () {
  $(".to-show").show();
});

$("#btn-color").click(function () {
  $(".inner-box").css("background-color", "#181414");
});
