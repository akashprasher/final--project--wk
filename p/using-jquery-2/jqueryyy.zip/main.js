$("#iAmButton").click(function () {
  $(".inner-border").removeClass("inner-border");
  $("paragraph").addClass("pink");
  $("h1").toggleClass("black");
});
